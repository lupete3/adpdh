const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('#main-nav');
function closeMenu() {
  toggle.setAttribute('aria-expanded', 'false');
  nav.classList.remove('is-open');
}
toggle.addEventListener('click', () => {
  const open = toggle.getAttribute('aria-expanded') !== 'true';
  toggle.setAttribute('aria-expanded', String(open));
  nav.classList.toggle('is-open', open);
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  closeMenu();
  document.querySelectorAll('.nav-more').forEach(menu => { menu.open = false; });
}));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    closeMenu();
    document.querySelectorAll('.nav-more').forEach(menu => { menu.open = false; });
  }
});
document.addEventListener('click', event => {
  document.querySelectorAll('.nav-more').forEach(menu => {
    if (!menu.contains(event.target)) menu.open = false;
  });
});
for (const [trigger, target] of [['[data-open-donation]', '#donation-dialog'], ['[data-open-legal]', '#legal-dialog']]) {
  const dialog = document.querySelector(target);
  if (!dialog) continue;
  document.querySelectorAll(trigger).forEach(button => button.addEventListener('click', () => dialog.showModal()));
  dialog.querySelector('[data-close]').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => {
    const rect = dialog.getBoundingClientRect();
    if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
  });
}
document.querySelector('#year').textContent = new Date().getFullYear();

// Apparitions finies : aucun contenu ne dépend de JavaScript pour être visible.
const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
const header = document.querySelector('.header');
let headerFrame = false;
function updateHeader() {
  header.classList.toggle('is-scrolled', window.scrollY > 40);
  headerFrame = false;
}
window.addEventListener('scroll', () => {
  if (!headerFrame) {
    headerFrame = true;
    requestAnimationFrame(updateHeader);
  }
}, { passive: true });
updateHeader();
if ('IntersectionObserver' in window && !motionPreference.matches) {
  const entranceObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('reveal-enter');
      entranceObserver.unobserve(entry.target);
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.section-heading, .pillar, .activity-list article, .impact-metrics > div, .partnership-types, .empty-state').forEach(element => entranceObserver.observe(element));
  motionPreference.addEventListener('change', event => {
    if (event.matches) entranceObserver.disconnect();
  });
}
/* Contact remains a local demonstration, without submission or persistence. */
const contactDemo = document.querySelector('#contact-demo');
if (contactDemo) {
  const feedback = document.querySelector('#contact-feedback');
  contactDemo.addEventListener('submit', event => {
    event.preventDefault();
    feedback.textContent = 'Vérification terminée : les champs sont valides. Démonstration uniquement — aucun message envoyé ni enregistré. Pour joindre ADPDH, écrivez à contact@adpdh.org.';
  });
  contactDemo.addEventListener('input', () => { feedback.textContent = ''; });
}
